# AttendanceApp

Projekt bereit zum Hochladen in GitHub. Workflow baut APK und lädt Artifact hoch.